import * as THREE from 'three';

export default class TitleObject {
  constructor() {
    this.uniforms = {
      time: {
        type: 'f',
        value: 0
      },
      resolution: {
        type: 'v2',
        value: new THREE.Vector2()
      },
      texture: {
        type: 't',
        value: null
      }
    };
    this.obj;
    this.isLoaded = false;
    this.mousePosition = new THREE.Vector2();
  }

  loadTexture(callback) {
    const loader = new THREE.TextureLoader();
    loader.load('/sketch-threejs/img/index/appk.png', (texture) => {
      texture.magFilter = THREE.NearestFilter;
      texture.minFilter = THREE.NearestFilter;
      this.uniforms.texture.value = texture;
      this.obj = this.createObj();
      this.isLoaded = true;
      callback();
    });
  }

  createObj() {
    // Check if the device is a mobile device
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    // Define initial size parameters
    let width = 800;
    let height = 104;
    
    // If it's a mobile device, adjust the size
    if (isMobile) {
        width = 330; // Set the width to a smaller value for mobile
        height = 42; // Set the height proportionally, or adjust as needed
    }
    
    // Create the Mesh with the adjusted size
    return new THREE.Mesh(
        new THREE.PlaneGeometry(width, height, 40, 10),
        new THREE.RawShaderMaterial({
            uniforms: this.uniforms,
            vertexShader: require('./glsl/titleObject.vs').default,
            fragmentShader: require('./glsl/titleObject.fs').default,
            transparent: true,
        })
    );
}

  updateCursorPosition(x, y) {
    // Update mouse position based on the normalized device coordinates
    this.mousePosition.x = (x / window.innerWidth) * 2 - 1;
    this.mousePosition.y = -(y / window.innerHeight) * 2 + 1;
  }

  render(time) {
    if (!this.isLoaded) return;

    // Update uniform values
    this.uniforms.time.value += time;
    this.uniforms.resolution.value.x = window.innerWidth;
    this.uniforms.resolution.value.y = window.innerHeight;

    // Calculate rotation based on cursor position
    if (this.obj) {
      this.obj.rotation.x = this.mousePosition.y * Math.PI / 4;
      this.obj.rotation.y = this.mousePosition.x * Math.PI / 4;
    }
  }
}
