precision highp float;

uniform float time;

varying vec3 vPosition;

const float duration = 8.0;
const float delay = 4.0;

#pragma glslify: convertHsvToRgb = require(@ykob/glsl-util/src/convertHsvToRgb);

void main() {
  float now = clamp((time - delay) / duration, 0.0, 1.0);
  float opacity = (1.0 - length(vPosition.xy / vec2(512.0))) * 0.6 * now;
  vec3 v = normalize(vPosition);
  vec3 rgb = convertHsvToRgb(vec3(0.5 + (v.x + v.y + v.x) / 40.0 + time * 0.1, 0.4, 1.0));
      vec3 color = vec3(73.0 / 255.0, 144.0 / 255.0, 238.0 / 255.0); // #4990EE

    gl_FragColor = vec4(color, opacity);
    // gl_FragColor = vec4(rgb,opacity);


  //   // Calculate blue color only
  // vec3 rgb = vec3(0.0, 0.0, abs(v.z)); // Z-coordinate represents blue in normalized space
  // // Scale the blue component by opacity
  // rgb = mix(vec3(0.0), rgb, opacity);
  // gl_FragColor = vec4(rgb, opacity);
}
