precision highp float;

uniform float time;

#pragma glslify: convertHsvToRgb = require(@ykob/glsl-util/src/convertHsvToRgb);

// Define the fixed color in RGB format
const vec3 fixedColor = vec3(73.0 / 255.0, 144.0 / 255.0, 238.0 / 255.0); // #4990EE

void main() {
    // Output the fixed color with a fixed opacity
    gl_FragColor = vec4(fixedColor, 0.25); // Opacity set to 0.25
}